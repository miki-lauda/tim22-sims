package model;
import java.util.List;

import main.MainWindow;

public abstract class Document {
	
	public abstract void showFields(State currState, MainWindow mw);
	public abstract boolean provjeraPrelazaStanja(State st);
	public abstract void fillFieldValues();
	
}
