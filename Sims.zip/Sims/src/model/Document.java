package model;
import java.util.List;

public abstract class Document {
	
	public abstract void showFields(State currState);
	
}
