package model;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import main.MainWindow;

public class AccessPermit extends Document {
	
	private Field status;
	private Field name;
	private Field dateTime;
	private Field answers;
	private Field revNo;
	private Field prevState;
	private Field denyingReasons;
	private Field equipment;
	private Field points;
	private Field phoneNo;
	private HashMap<FieldType,JTextField> mapa;
	
	public AccessPermit() {
		super();
		this.status = new Field(FieldType.ACCESS_PERMIT_STATUS,"Status: ", "");
		this.name = new Field(FieldType.ACCESS_PERMIT_NAME,"Name: ", "");
		this.dateTime = new Field(FieldType.ACCESS_PERMIT_DATE_TIME, "Date: ", "");
		this.answers = new Field(FieldType.ACCESS_PERMIT_ANSWERS, "Answers: ", "");
		this.revNo = new Field(FieldType.SAFETY_DOCUMENT_REV_NO, "Rev No: ", "");
		this.prevState = new Field(FieldType.ACCESS_PERMIT_PREV_STATE, "Prev state: ", "");
		this.denyingReasons = new Field(FieldType.ACCESS_PERMIT_DENYING_REASON, "Denying reasons: ", "");
		this.equipment = new Field(FieldType.ACCESS_PERMIT_EQUIPMENT, "Equipment: ", "");
		this.points = new Field(FieldType.ACCESS_PERMIT_POINTS, "Points: ", "");
		this.phoneNo = new Field(FieldType.ACCESS_PERMIT_PHONE_NO, "Phone number: ", "");
		this.mapa = new HashMap<FieldType, JTextField>();
	}
	
	public AccessPermit(Field status, Field name, Field dateTime, Field answers, Field revNo, Field prevState,
			Field denyingReasons, Field equipment, Field points, Field phoneNo) {
		super();
		this.status = status;
		this.name = name;
		this.dateTime = dateTime;
		this.answers = answers;
		this.revNo = revNo;
		this.prevState = prevState;
		this.denyingReasons = denyingReasons;
		this.equipment = equipment;
		this.points = points;
		this.phoneNo = phoneNo;
	}
	
	@SuppressWarnings("deprecation")
	@Override
	public void showFields(State currState, MainWindow mw) {
		JPanel panel = mw.getPanel();
		panel.setLayout(new GridLayout(10, 2));
		addLabel(panel, status, findStatus(currState, status.getType()), currState);
		addLabel(panel, name, findStatus(currState, name.getType()), currState);
		addLabel(panel, dateTime, findStatus(currState, dateTime.getType()), currState);
		addLabel(panel, answers, findStatus(currState, answers.getType()), currState);
		addLabel(panel, revNo, findStatus(currState, revNo.getType()), currState);
		addLabel(panel, prevState, findStatus(currState, prevState.getType()), currState);
		addLabel(panel, denyingReasons, findStatus(currState, denyingReasons.getType()), currState);
		addLabel(panel, equipment, findStatus(currState, equipment.getType()), currState);
		addLabel(panel, points, findStatus(currState, points.getType()), currState);
		addLabel(panel, phoneNo, findStatus(currState, phoneNo.getType()), currState);
		
		mw.add(panel,BorderLayout.CENTER);
		mw.pack();
	}
	
	@SuppressWarnings("deprecation")
	private void addLabel(JPanel jp, Field field, Status st, State currState) {
		JLabel jl = new JLabel(asterisk(field.getType(), currState) + field.getFieldName());
		JTextField userText = new JTextField();
		userText.setText(field.getValue());
		userText.setColumns(2);
		if(st == Status.DENY) {
			userText.setEditable(false);
		} else if (st == Status.HIDE) {
			jl.setVisible(false);
			userText.setVisible(false);
		}
		jp.add(jl);
		jp.add(userText);
		mapa.put(field.getType(), userText);
	}
	
	private String asterisk(FieldType ft, State currState) {
		String ast = "";
		for(FieldType polje : currState.getStateMandatoryFields()) {
			if (ft == polje) {
				return "*";
			}
		}
		return ast;
	}
	
	private Status findStatus(State st, FieldType fd) {
		for(FieldType polje : st.getStateDenyModifyingFields()) {
			if (fd == polje) {
				return Status.DENY;
			}
		}
		
		for(FieldType polje : st.getStateHideFields()) {
			if (fd == polje) {
				return Status.HIDE;
			}
		}
		return null;
	}
	
	@Override
	public boolean provjeraPrelazaStanja(State st) {
		for(FieldType tp : st.getStateMandatoryFields()) {
			if(mapa.get(tp).getText().equals("")) {
				return false;
			}
		}
		return true;
	}
	
	@Override
	public void fillFieldValues() {
		for (Map.Entry<FieldType, JTextField> pair : mapa.entrySet()) {
		    switch(pair.getKey()) {
		    case ACCESS_PERMIT_STATUS:
		    	this.status.setValue(pair.getValue().getText());
		    	break;
		    case ACCESS_PERMIT_NAME:
		    	this.name.setValue(pair.getValue().getText());
		    	break;
		    case ACCESS_PERMIT_DATE_TIME:
		    	this.dateTime.setValue(pair.getValue().getText());
		    	break;
		    case SAFETY_DOCUMENT_REV_NO:
		    	this.revNo.setValue(pair.getValue().getText());
		    	break;
		    case ACCESS_PERMIT_ANSWERS:
		    	this.answers.setValue(pair.getValue().getText());
		    	break;
		    case ACCESS_PERMIT_DENYING_REASON:
		    	this.denyingReasons.setValue(pair.getValue().getText());
		    	break;
		    case ACCESS_PERMIT_EQUIPMENT:
		    	this.equipment.setValue(pair.getValue().getText());
		    	break;
		    case ACCESS_PERMIT_PHONE_NO:
		    	this.phoneNo.setValue(pair.getValue().getText());
		    	break;
		    case ACCESS_PERMIT_POINTS:
		    	this.points.setValue(pair.getValue().getText());
		    	break;
		    case ACCESS_PERMIT_PREV_STATE:
		    	this.prevState.setValue(pair.getValue().getText());
		    	break;
		    }
		}
	}
	
 	public Field getStatus() {
		return status;
	}

	public void setStatus(Field status) {
		this.status = status;
	}

	public Field getName() {
		return name;
	}

	public void setName(Field name) {
		this.name = name;
	}

	public Field getDateTime() {
		return dateTime;
	}

	public void setDateTime(Field dateTime) {
		this.dateTime = dateTime;
	}

	public Field getAnswers() {
		return answers;
	}

	public void setAnswers(Field answers) {
		this.answers = answers;
	}

	public Field getRevNo() {
		return revNo;
	}

	public void setRevNo(Field revNo) {
		this.revNo = revNo;
	}

	public Field getPrevState() {
		return prevState;
	}

	public void setPrevState(Field prevState) {
		this.prevState = prevState;
	}

	public Field getDenyingReasons() {
		return denyingReasons;
	}

	public void setDenyingReasons(Field denyingReasons) {
		this.denyingReasons = denyingReasons;
	}

	public Field getEquipment() {
		return equipment;
	}

	public void setEquipment(Field equipment) {
		this.equipment = equipment;
	}

	public Field getPoints() {
		return points;
	}

	public void setPoints(Field points) {
		this.points = points;
	}

	public Field getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(Field phoneNo) {
		this.phoneNo = phoneNo;
	}

	@Override
	public String toString() {
		return "AccessPermit [status=" + status + ", name=" + name + ", dateTime=" + dateTime + ", answers=" + answers
				+ ", revNo=" + revNo + ", prevState=" + prevState + ", denyingReasons=" + denyingReasons
				+ ", equipment=" + equipment + ", points=" + points + ", phoneNo=" + phoneNo + "]";
	}
	
}	
