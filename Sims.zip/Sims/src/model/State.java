package model;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JToolBar;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamImplicit;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

import main.MainWindow;

@XStreamAlias("State")
public class State {

	@XStreamAsAttribute
	private int stateId;
	private String lifecycleName;
	private String displayName;
	private List<Semantic> stateSemantic;
	private List<Integer> stateTransitions;
	@XStreamOmitField
	private List<Transition> transitions;
	private List<FieldType> stateDenyModifyingFields;
	private List<FieldType> stateHideFields;
	private List<FieldType> stateMandatoryFields;
	@XStreamOmitField
	private Document document;

	public State() {

	}

	public State(int stateId, String lifecycleName, String displayName, List<Semantic> stateSemantic,
			List<Integer> stateTransitions, List<Transition> transitions, List<FieldType> stateDenyModifyingFields,
			List<FieldType> stateHideFields, List<FieldType> stateMandatoryFields, Document document) {
		this.stateId = stateId;
		this.lifecycleName = lifecycleName;
		this.displayName = displayName;
		this.stateSemantic = stateSemantic;
		this.stateTransitions = stateTransitions;
		this.transitions = transitions;
		this.stateDenyModifyingFields = stateDenyModifyingFields;
		this.stateHideFields = stateHideFields;
		this.stateMandatoryFields = stateMandatoryFields;
		this.document = document;
	}

	public State(int stateId, String lifecycleName, String displayName, List<Semantic> stateSemantic,
			List<Integer> stateTransitions, List<FieldType> stateDenyModifyingFields, List<FieldType> stateHideFields,
			List<FieldType> stateMandatoryFields) {
		this.stateId = stateId;
		this.lifecycleName = lifecycleName;
		this.displayName = displayName;
		this.stateSemantic = stateSemantic;
		this.stateTransitions = stateTransitions;
		this.stateDenyModifyingFields = stateDenyModifyingFields;
		this.stateHideFields = stateHideFields;
		this.stateMandatoryFields = stateMandatoryFields;
	}

	public void showDocumentInState(MainWindow mw) {
		document.showFields(this, mw);
		
		ActionListener command = new CommandAction();
		JToolBar tb = mw.getTb();
		JPanel jp = new JPanel();
		for (Transition tr : this.transitions) {
			JButton jb = new JButton(tr.getLifecycleName().split(" ")[2]);
			jb.addActionListener(command);
			jp.add(jb, BorderLayout.EAST);
		}
		tb.setFloatable(false);
		tb.add(jp);
		mw.add(tb, BorderLayout.NORTH);
		mw.pack();
	}
	
	private class CommandAction implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			fillFieldValues();
			for (Transition tr : transitions) {
				if (tr.getLifecycleName().split(" ")[2].equals(event.getActionCommand())) {
					MainWindow.getInstance().promijeniStanje(tr, provjeraPrelazaStanja());
					break;
				}
			}
		}
	}

	private void fillFieldValues() {
		this.document.fillFieldValues();
	}
	
	private boolean provjeraPrelazaStanja() {
		return document.provjeraPrelazaStanja(this);
	}

	public int getStateId() {
		return stateId;
	}

	public void setStateId(int stateId) {
		this.stateId = stateId;
	}

	public String getLifecycleName() {
		return lifecycleName;
	}

	public void setLifecycleName(String lifecycleName) {
		this.lifecycleName = lifecycleName;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public List<Semantic> getStateSemantic() {
		return stateSemantic;
	}

	public void setStateSemantic(List<Semantic> stateSemantic) {
		this.stateSemantic = stateSemantic;
	}

	public List<Integer> getStateTransitions() {
		return stateTransitions;
	}

	public void setStateTransitions(List<Integer> stateTransitions) {
		this.stateTransitions = stateTransitions;
	}

	public List<FieldType> getStateDenyModifyingFields() {
		return stateDenyModifyingFields;
	}

	public void setStateDenyModifyingFields(List<FieldType> stateDenyModifyingFields) {
		this.stateDenyModifyingFields = stateDenyModifyingFields;
	}

	public List<FieldType> getStateHideFields() {
		return stateHideFields;
	}

	public void setStateHideFields(List<FieldType> stateHideFields) {
		this.stateHideFields = stateHideFields;
	}

	public List<FieldType> getStateMandatoryFields() {
		return stateMandatoryFields;
	}

	public void setStateMandatoryFields(List<FieldType> stateMandatoryFields) {
		this.stateMandatoryFields = stateMandatoryFields;
	}

	public List<Transition> getTransitions() {
		return transitions;
	}

	public void setTransitions(List<Transition> transitions) {
		this.transitions = transitions;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	@Override
	public String toString() {
		return "State [stateId=" + stateId + ", lifecycleName=" + lifecycleName + ", displayName=" + displayName
				+ ", stateSemantic=" + stateSemantic + ", stateTransitions=" + stateTransitions + ", transitions="
				+ transitions + ", stateDenyModifyingFields=" + stateDenyModifyingFields + ", stateHideFields="
				+ stateHideFields + ", stateMandatoryFields=" + stateMandatoryFields + ", document=" + document + "]";
	}

}
