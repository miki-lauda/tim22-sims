package main;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Box;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.filechooser.FileFilter;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.sax.SAXTransformerFactory;
import javax.xml.transform.stream.StreamResult;

import org.xml.sax.InputSource;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;

import model.AccessPermit;
import model.Data;
import model.Document;
import model.Field;
import model.FieldType;
import model.Semantic;
import model.State;
import model.Transition;

class MainWindow extends JFrame {

	private static final long serialVersionUID = 8087603199136216708L;
	private Data data;
	private Document document;
	private State currentState;
	
	private static MainWindow instance = null;
	
	public static MainWindow getInstance() {
		if (instance == null) {
			instance = new MainWindow();
		}
		return instance;
	}

	private MainWindow() {
		
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException
				| UnsupportedLookAndFeelException e) {
			e.printStackTrace();
		}
		
		boolean validFile = false;
		while (!validFile) {
			validFile = chooseFile(true);
		}
		
		Toolkit kit = Toolkit.getDefaultToolkit();
		Dimension screenSize = kit.getScreenSize();
		int screenHeight = screenSize.height;
		int screenWidth = screenSize.width;
		Dimension windowSize = new Dimension(650, 900);
		
		setSize(windowSize);
		setLocation((screenWidth - windowSize.width) / 2, (screenHeight - windowSize.height) / 2);

		setTitle("State Machine");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JMenuBar menuBar = new JMenuBar();
		JMenu fileMenu;

		fileMenu = new JMenu("File");
		menuBar.add(fileMenu);
		
		JMenuItem newMenuItem = new JMenuItem("New");
		fileMenu.add(newMenuItem);
		newMenuItem.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				chooseFile(false);
			}
		});
		
		menuBar.setPreferredSize(new Dimension(200, 40));
		setJMenuBar(menuBar);
		
		setVisible(true);
	}

	private boolean chooseFile(boolean startOfApp) {
		boolean retVal = false;
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.addChoosableFileFilter(new FileFilter() {
			
			@Override
		    public String getDescription() {
		        return "XML Documents (*.xml)";
		    }
		 
			@Override
		    public boolean accept(File f) {
		        if (f.isDirectory()) {
		            return true;
		        } else {
		            return f.getName().toLowerCase().endsWith(".xml");
		        }
		    }
		});
		
		fileChooser.setAcceptAllFileFilterUsed(false);
        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
        	
            try {
				String xml = readFile(fileChooser.getSelectedFile().getAbsolutePath());
				XStream xstream = new XStream(new StaxDriver());
				XStream.setupDefaultSecurity(xstream);
				Class<?>[] classes = new Class[] { Data.class, Transition.class, State.class, Field.class };
				xstream.allowTypes(classes);
				
				xstream.processAnnotations(Transition.class);
				xstream.processAnnotations(State.class);
				xstream.processAnnotations(FieldType.class);
				xstream.processAnnotations(Data.class);
				xstream.processAnnotations(Semantic.class);
				Data dataFromXml = new Data();
				try {
					dataFromXml = (Data) xstream.fromXML(xml);
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(this, "File not valid!");
					retVal = false;
					return retVal;
				}
			    
			    int numberOfInitStates = 0;
			    int numberOfFinalStates = 0;
			    for (State state : dataFromXml.getStates()) {
			    	for (Semantic semantic : state.getStateSemantic())
			    	if (semantic == Semantic.Init) {
			    		numberOfInitStates++;
			    	} else if (semantic == Semantic.Final) {
			    		numberOfFinalStates++;
			    	}
			    }
			    if (numberOfInitStates == 1 && numberOfFinalStates == 1) {
			    	this.data = dataFromXml;
			    	this.data.setConnections();
					this.document = new AccessPermit();
					for (State st : this.data.getStates()) {
						for (Semantic sem : st.getStateSemantic()) {
							if (sem == Semantic.Init) {
								this.currentState = st;
								st.setDocument(this.document);
								st.showDocumentInState();
							}
						}
					}
			    	retVal = true;
			    	return retVal;
			    } else {
			    	JOptionPane.showMessageDialog(this, "File not valid!");
			    	return false;
			    }
            } catch (IOException e) {
				JOptionPane.showMessageDialog(this, "Wrong file!");
				retVal = false;
				return retVal;
			}
        } else if (result == JFileChooser.CANCEL_OPTION) {
        	if (startOfApp) {
        		System.exit(0);
        	}
        }
        return retVal;
	}
	
	private String readFile(String file) throws IOException {
	    BufferedReader reader = new BufferedReader(new FileReader(file));
	    String line = null;
	    StringBuilder stringBuilder = new StringBuilder();
	    String ls = System.getProperty("line.separator");

	    try {
	        while((line = reader.readLine()) != null) {
	            stringBuilder.append(line);
	            stringBuilder.append(ls);
	        }
	        return stringBuilder.toString();
	    } finally {
	        reader.close();
	    }
	}
	
	public Data getData() {
		return data;
	}

	public void setData(Data data) {
		this.data = data;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	public State getCurrentState() {
		return currentState;
	}

	public void setCurrentState(State currentState) {
		this.currentState = currentState;
	}

	public static void main(String[] args) {
		MainWindow mw = getInstance();
	}
}