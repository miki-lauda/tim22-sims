
public class AccessPermit {
	
	private Field status;
	private Field name;
	private Field dateTime;
	private Field answers;
	private Field revNo;
	private Field prevState;
	private Field denyingReasons;
	private Field equipment;
	private Field points;
	private Field phoneNo;
	
	public AccessPermit() {
		
	}

	public AccessPermit(Field status, Field name, Field dateTime, Field answers, Field revNo, Field prevState,
			Field denyingReasons, Field equipment, Field points, Field phoneNo) {
		this.status = status;
		this.name = name;
		this.dateTime = dateTime;
		this.answers = answers;
		this.revNo = revNo;
		this.prevState = prevState;
		this.denyingReasons = denyingReasons;
		this.equipment = equipment;
		this.points = points;
		this.phoneNo = phoneNo;
	}

	public Field getStatus() {
		return status;
	}

	public void setStatus(Field status) {
		this.status = status;
	}

	public Field getName() {
		return name;
	}

	public void setName(Field name) {
		this.name = name;
	}

	public Field getDateTime() {
		return dateTime;
	}

	public void setDateTime(Field dateTime) {
		this.dateTime = dateTime;
	}

	public Field getAnswers() {
		return answers;
	}

	public void setAnswers(Field answers) {
		this.answers = answers;
	}

	public Field getRevNo() {
		return revNo;
	}

	public void setRevNo(Field revNo) {
		this.revNo = revNo;
	}

	public Field getPrevState() {
		return prevState;
	}

	public void setPrevState(Field prevState) {
		this.prevState = prevState;
	}

	public Field getDenyingReasons() {
		return denyingReasons;
	}

	public void setDenyingReasons(Field denyingReasons) {
		this.denyingReasons = denyingReasons;
	}

	public Field getEquipment() {
		return equipment;
	}

	public void setEquipment(Field equipment) {
		this.equipment = equipment;
	}

	public Field getPoints() {
		return points;
	}

	public void setPoints(Field points) {
		this.points = points;
	}

	public Field getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(Field phoneNo) {
		this.phoneNo = phoneNo;
	}

	@Override
	public String toString() {
		return "AccessPermit [status=" + status + ", name=" + name + ", dateTime=" + dateTime + ", answers=" + answers
				+ ", revNo=" + revNo + ", prevState=" + prevState + ", denyingReasons=" + denyingReasons
				+ ", equipment=" + equipment + ", points=" + points + ", phoneNo=" + phoneNo + "]";
	}
	
}	
