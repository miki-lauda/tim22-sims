
public enum Semantic {
	Init,
	SaveEnabled,
	DeleteEnabled,
	Final
}
