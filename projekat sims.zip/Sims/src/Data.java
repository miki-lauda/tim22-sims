import java.util.List;

public class Data {
	
	private List<Transition> transitions;
	private List<State> states;
	
	public Data() {
		
	}
	
	public Data(List<Transition> transitions, List<State> states) {
		this.transitions = transitions;
		this.states = states;
	}

	public List<Transition> getTransitions() {
		return transitions;
	}

	public void setTransitions(List<Transition> transitions) {
		this.transitions = transitions;
	}

	public List<State> getStates() {
		return states;
	}

	public void setStates(List<State> states) {
		this.states = states;
	}
	
	@Override
	public String toString() {
		return "Data [transitions=" + transitions + ", states=" + states + "]";
	}
}
