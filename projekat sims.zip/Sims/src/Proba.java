import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.sax.SAXTransformerFactory;
import javax.xml.transform.stream.StreamResult;

import org.xml.sax.InputSource;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;

public class Proba {

	public static void main(String[] args) {
		Transition t1 = new Transition(1, "Draft to Submit", 2, 1);
		Transition t2 = new Transition(2, "Submit to Publish", 3, 2);
		Transition t3 = new Transition(3, "Publish to Return", 4, 3);
		Transition t4 = new Transition(4, "Return to Complete", 5, 4);
		Transition t5 = new Transition(5, "Submit to Deny", 6, 2);
		
		List<Semantic> stateSemantic = new ArrayList<Semantic>();
		stateSemantic.add(Semantic.Init);
		stateSemantic.add(Semantic.SaveEnabled);
		stateSemantic.add(Semantic.DeleteEnabled);
		List<Integer> stateTransitions = new ArrayList<Integer>();
		stateTransitions.add(1);
		List<FieldType> stateDenyModifyingFields = new ArrayList<FieldType>();
		stateDenyModifyingFields.add(FieldType.ACCESS_PERMIT_STATUS);
		stateDenyModifyingFields.add(FieldType.ACCESS_PERMIT_NAME);
		stateDenyModifyingFields.add(FieldType.ACCESS_PERMIT_DATE_TIME);
		stateDenyModifyingFields.add(FieldType.ACCESS_PERMIT_ANSWERS);
		List<FieldType> stateHideFields = new ArrayList<FieldType>();
		stateHideFields.add(FieldType.ACCESS_PERMIT_NAME);
		stateHideFields.add(FieldType.ACCESS_PERMIT_DATE_TIME);
		stateHideFields.add(FieldType.SAFETY_DOCUMENT_REV_NO);
		stateHideFields.add(FieldType.ACCESS_PERMIT_PREV_STATE);
		stateHideFields.add(FieldType.ACCESS_PERMIT_DENYING_REASON);
		List<FieldType> stateMandatoryFields = new ArrayList<FieldType>();
		State s1 = new State(1, "Init state", "Draft", stateSemantic, stateTransitions, stateDenyModifyingFields, stateHideFields, stateMandatoryFields);
		
		List<Semantic> stateSemantic2 = new ArrayList<Semantic>();
		stateSemantic2.add(Semantic.SaveEnabled);
		List<Integer> stateTransitions2 = new ArrayList<Integer>();
		stateTransitions2.add(2);
		stateTransitions2.add(5);
		List<FieldType> stateDenyModifyingFields2 = new ArrayList<FieldType>();
		stateDenyModifyingFields2.add(FieldType.ACCESS_PERMIT_STATUS);
		stateDenyModifyingFields2.add(FieldType.ACCESS_PERMIT_NAME);
		stateDenyModifyingFields2.add(FieldType.ACCESS_PERMIT_DATE_TIME);
		stateDenyModifyingFields2.add(FieldType.ACCESS_PERMIT_ANSWERS);
		List<FieldType> stateHideFields2 = new ArrayList<FieldType>();
		stateHideFields2.add(FieldType.ACCESS_PERMIT_NAME);
		stateHideFields2.add(FieldType.ACCESS_PERMIT_DATE_TIME);
		stateHideFields2.add(FieldType.SAFETY_DOCUMENT_REV_NO);
		stateHideFields2.add(FieldType.ACCESS_PERMIT_PREV_STATE);
		stateHideFields2.add(FieldType.ACCESS_PERMIT_DENYING_REASON);
		List<FieldType> stateMandatoryFields2 = new ArrayList<FieldType>();
		stateMandatoryFields2.add(FieldType.ACCESS_PERMIT_EQUIPMENT);
		State s2 = new State(2, "Submit", "Submited", stateSemantic2, stateTransitions2, stateDenyModifyingFields2, stateHideFields2, stateMandatoryFields2);
		
		List<Semantic> stateSemantic3 = new ArrayList<Semantic>();
		stateSemantic3.add(Semantic.SaveEnabled);
		List<Integer> stateTransitions3 = new ArrayList<Integer>();
		stateTransitions3.add(3);
		List<FieldType> stateDenyModifyingFields3 = new ArrayList<FieldType>();
		stateDenyModifyingFields3.add(FieldType.ACCESS_PERMIT_STATUS);
		stateDenyModifyingFields3.add(FieldType.ACCESS_PERMIT_NAME);
		stateDenyModifyingFields3.add(FieldType.ACCESS_PERMIT_DATE_TIME);
		List<FieldType> stateHideFields3 = new ArrayList<FieldType>();
		stateHideFields3.add(FieldType.ACCESS_PERMIT_PREV_STATE);
		stateHideFields3.add(FieldType.ACCESS_PERMIT_DENYING_REASON);
		List<FieldType> stateMandatoryFields3 = new ArrayList<FieldType>();
		stateMandatoryFields3.add(FieldType.ACCESS_PERMIT_EQUIPMENT);
		stateMandatoryFields3.add(FieldType.ACCESS_PERMIT_POINTS);
		State s3 = new State(3, "Publish", "Published", stateSemantic3, stateTransitions3, stateDenyModifyingFields3, stateHideFields3, stateMandatoryFields3);

		List<Semantic> stateSemantic4 = new ArrayList<Semantic>();
		stateSemantic4.add(Semantic.SaveEnabled);
		List<Integer> stateTransitions4 = new ArrayList<Integer>();
		stateTransitions4.add(4);
		List<FieldType> stateDenyModifyingFields4 = new ArrayList<FieldType>();
		stateDenyModifyingFields4.add(FieldType.ACCESS_PERMIT_STATUS);
		stateDenyModifyingFields4.add(FieldType.ACCESS_PERMIT_NAME);
		stateDenyModifyingFields4.add(FieldType.ACCESS_PERMIT_DATE_TIME);
		stateDenyModifyingFields4.add(FieldType.ACCESS_PERMIT_PHONE_NO);
		List<FieldType> stateHideFields4 = new ArrayList<FieldType>();
		stateHideFields4.add(FieldType.ACCESS_PERMIT_PREV_STATE);
		stateHideFields4.add(FieldType.ACCESS_PERMIT_DENYING_REASON);
		List<FieldType> stateMandatoryFields4 = new ArrayList<FieldType>();
		stateMandatoryFields4.add(FieldType.ACCESS_PERMIT_EQUIPMENT);
		stateMandatoryFields4.add(FieldType.ACCESS_PERMIT_POINTS);
		stateMandatoryFields4.add(FieldType.ACCESS_PERMIT_ANSWERS);
		State s4 = new State(4, "Return", "Returned", stateSemantic4, stateTransitions4, stateDenyModifyingFields4, stateHideFields4, stateMandatoryFields4);
		
		List<Semantic> stateSemantic5 = new ArrayList<Semantic>();
		stateSemantic5.add(Semantic.Final);
		List<Integer> stateTransitions5 = new ArrayList<Integer>();
		List<FieldType> stateDenyModifyingFields5 = new ArrayList<FieldType>();
		stateDenyModifyingFields5.add(FieldType.ACCESS_PERMIT_STATUS);
		stateDenyModifyingFields5.add(FieldType.ACCESS_PERMIT_NAME);
		stateDenyModifyingFields5.add(FieldType.ACCESS_PERMIT_DATE_TIME);
		stateDenyModifyingFields5.add(FieldType.ACCESS_PERMIT_PHONE_NO);
		List<FieldType> stateHideFields5 = new ArrayList<FieldType>();
		stateHideFields5.add(FieldType.ACCESS_PERMIT_PREV_STATE);
		stateHideFields5.add(FieldType.ACCESS_PERMIT_DENYING_REASON);
		List<FieldType> stateMandatoryFields5 = new ArrayList<FieldType>();
		stateMandatoryFields5.add(FieldType.ACCESS_PERMIT_EQUIPMENT);
		stateMandatoryFields5.add(FieldType.ACCESS_PERMIT_POINTS);
		State s5 = new State(5, "Complete", "Completed", stateSemantic5, stateTransitions5, stateDenyModifyingFields5, stateHideFields5, stateMandatoryFields5);

		List<Semantic> stateSemantic6 = new ArrayList<Semantic>();
		stateSemantic6.add(Semantic.Final);
		List<Integer> stateTransitions6 = new ArrayList<Integer>();
		List<FieldType> stateDenyModifyingFields6 = new ArrayList<FieldType>();
		stateDenyModifyingFields6.add(FieldType.ACCESS_PERMIT_STATUS);
		stateDenyModifyingFields6.add(FieldType.ACCESS_PERMIT_NAME);
		stateDenyModifyingFields6.add(FieldType.ACCESS_PERMIT_DATE_TIME);
		stateDenyModifyingFields6.add(FieldType.ACCESS_PERMIT_PHONE_NO);
		stateDenyModifyingFields6.add(FieldType.ACCESS_PERMIT_EQUIPMENT);
		stateDenyModifyingFields6.add(FieldType.ACCESS_PERMIT_POINTS);
		stateDenyModifyingFields6.add(FieldType.ACCESS_PERMIT_ANSWERS);
		List<FieldType> stateHideFields6 = new ArrayList<FieldType>();
		stateHideFields6.add(FieldType.ACCESS_PERMIT_PREV_STATE);
		stateHideFields6.add(FieldType.ACCESS_PERMIT_DENYING_REASON);
		List<FieldType> stateMandatoryFields6 = new ArrayList<FieldType>();
		stateMandatoryFields6.add(FieldType.ACCESS_PERMIT_EQUIPMENT);
		stateMandatoryFields6.add(FieldType.ACCESS_PERMIT_POINTS);
		State s6 = new State(6, "Deny", "Denied", stateSemantic6, stateTransitions6, stateDenyModifyingFields6, stateHideFields6, stateMandatoryFields6);
	
		List<Transition> lt = new ArrayList<Transition>(); 
		List<State> ls = new ArrayList<State>();
		lt.add(t1);
		lt.add(t2);
		lt.add(t3);
		lt.add(t4);
		lt.add(t5);
		ls.add(s1);
		ls.add(s2);
		ls.add(s3);
		ls.add(s4);
		ls.add(s5);
		ls.add(s6);
		
		Data d = new Data(lt, ls);
		
		XStream xstream = new XStream(new StaxDriver());
		xstream.processAnnotations(Transition.class);
		xstream.processAnnotations(State.class);
		String xml = xstream.toXML(d);
	    //System.out.println(formatXml(xml));
	    
	    Data d2 = (Data) xstream.fromXML(xml);
	    XStream xstream2 = new XStream(new StaxDriver());
		xstream2.processAnnotations(Transition.class);
		xstream2.processAnnotations(State.class);
		String xml2 = xstream2.toXML(d2);
		System.out.println(formatXml(xml2));
	}

	public static String formatXml(String xml) {
	  try {
	     Transformer serializer = SAXTransformerFactory.newInstance().newTransformer();
	     serializer.setOutputProperty(OutputKeys.INDENT, "yes");
	     serializer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
	     Source xmlSource = new SAXSource(new InputSource(
	        new ByteArrayInputStream(xml.getBytes())));
	     StreamResult res = new StreamResult(new ByteArrayOutputStream());            
	     serializer.transform(xmlSource, res);
	     return new String(((ByteArrayOutputStream)res.getOutputStream()).toByteArray());
	  } catch(Exception e) {
	     return xml;
   	  }
   }
}
